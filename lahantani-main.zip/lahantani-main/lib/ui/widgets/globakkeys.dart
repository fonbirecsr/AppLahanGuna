import 'package:flutter/widgets.dart';

class MyKeys {
  static final myKeys1 = GlobalKey();
  static final myKeys2 = GlobalKey();
}